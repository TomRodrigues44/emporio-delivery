# Empório das Coxinhas

Sistema de pedidos em React + Next.js

- Tela de pedidos com categorias
- Finalização com carrinho
- Pronto para integrar Supabase, MercadoPago e WhatsApp